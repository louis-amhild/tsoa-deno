This package contains the runtime helpers for tsoa.

For a comprehensive Readme, please refer to [the main readme](https://github.com/lukeautry/tsoa#readme).
