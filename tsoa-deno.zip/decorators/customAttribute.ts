export function CustomAttribute(_name: string, _value: string): Function {
  return () => {
    return;
  };
}
