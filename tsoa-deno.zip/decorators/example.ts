export function Example<T>(exampleModel: T, exampleLabel?: string): Function {
  return () => {
    return;
  };
}
