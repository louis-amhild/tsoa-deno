export function Options(value?: string): Function {
  return () => {
    return;
  };
}

export function Get(value?: string): Function {
  return () => {
    return;
  };
}

export function Post(value?: string): Function {
  return () => {
    return;
  };
}

export function Put(value?: string): Function {
  return () => {
    return;
  };
}

export function Patch(value?: string): Function {
  return () => {
    return;
  };
}

export function Delete(value?: string): Function {
  return () => {
    return;
  };
}

export function Head(value?: string): Function {
  return () => {
    return;
  };
}
