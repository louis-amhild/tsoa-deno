export function OperationId(value: string): Function {
  return () => {
    return;
  };
}
