export function Tags(...values: string[]): Function {
  return () => {
    return;
  };
}
